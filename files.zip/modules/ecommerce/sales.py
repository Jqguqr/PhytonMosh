print("Sales initialized", __name__)


def calc_tax():
    pass


def calc_shipping():
    pass
